# Copyright 2019 Splunk Inc. All rights reserved.

"""
### Features impacted by Splunk Python 3 migration.

The following features should not be supported in Splunk Python 3 migration.
"""

# Python Standard Libraries
import logging
import os
import re

# Third-Party Libraries
import bs4

# Custom Libraries
import splunk_appinspect
import splunk_appinspect.check_routine as check_routine

logger = logging.getLogger(__name__)


@splunk_appinspect.tags("splunk_appinspect", "removed_feature", 'ast', 'py3_migration')
@splunk_appinspect.cert_version(min="1.7.1")
def check_for_removed_m2crypto_usage(app, reporter, target_splunk_version):
    """
    Check removed M2Crypto usages.
    """
    # This package was removed in Splunk Python 3 migration and App shouldn't use it. However, Since 
    # we don't know whether the user has packaged their own M2Crypto. We only report 
    # warning once the usage is found.
    if target_splunk_version < "py3_migration":
        return
    reporter_output = ("Detect usage of M2Crypto. "
                       "With the upcoming Splunk Python 3 migration, this Python package will be removed, "
                       "and continuing to use this Python package may cause breakage. Please do not use it.")
    client = app.python_analyzer_client
    for file_path, ast_info in client.get_all_ast_infos():
        lines = ast_info.get_module_usage('M2Crypto', lineno_only=True)
        for line in lines:
            reporter.warn(reporter_output, file_path, line)


@splunk_appinspect.tags("splunk_appinspect", "removed_feature", "py3_migration")
def check_for_cherry_py_custom_controller_web_conf_endpoints(app, reporter, target_splunk_version):
    """Detect the existence of CherryPy endpoints. With the upcoming Splunk Python 3 migration,
    Splunkweb will run entirely on Python 3. As custom CherryPy endpoints (AKA custom web controls) run on Splunkweb,
    Python code in custom CherryPy endpoints must be upgraded to be compatible with Python 3.
    """
    # Checks to see if [endpoint:*] stanzas are defined in web.conf.
    if target_splunk_version < "py3_migration":
        return
    reporter_output = ("With the upcoming Splunk Python 3 migration,"
                       " Splunkweb will run entirely on Python 3."
                       " As custom CherryPy endpoints (AKA custom web controls) run on Splunkweb,"
                       " Python code in custom CherryPy endpoints must be upgraded to be compatible with Python 3,"
                       " and failing to upgrade it may cause breakage."
                       " Please ensure your CherryPy endpoint is compatible with Python 3."
                       " If you've finished your upgrade, please disregard this message.")
    if app.file_exists("default", "web.conf"):
        web_conf = app.web_conf()
        file_path = os.path.join("default", "web.conf")
        for section in web_conf.sections():
            if section.name.startswith("endpoint:"):

                reporter.warn(reporter_output, file_path, section.lineno)
    else:
        reporter_output = "No web.conf file exists."
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("splunk_appinspect", "py3_migration")
def check_for_existence_of_mako_template(app, reporter, target_splunk_version):
    '''Check for the existence of Mako template. Mako template should be compatible with Python 3 in
    the upcoming Splunk Python 3 migration.
    '''
    if target_splunk_version < "py3_migration":
        return
    reporter_output = ("With the upcoming Splunk Python 3 migration,"
                       " Splunk Web will run entirely on Python 3."
                       " As custom Mako templates run on Splunk Web,"
                       " Python code in Mako templates must be upgraded to be compatible with Python 3,"
                       " and failing to upgrade it may cause breakage."
                       " Please ensure your Mako template is compatible with Python 3."
                       " If you've finished your upgrade, please disregard this message.")
    for dir, file, ext in app.iterate_files(basedir='appserver', types=['.html']):
        current_file_relative_path = os.path.join(dir, file)
        current_file_full_path = app.get_filename(dir, file)
        if check_routine.is_mako_template(current_file_full_path):
            reporter.warn(reporter_output, current_file_relative_path)


@splunk_appinspect.tags("splunk_appinspect", "py3_migration")
def check_py2_command_scripts_and_scripted_lookup_exist(app, reporter, target_splunk_version):
    """Check that custom search commands have an Python script per
    stanza, or has scripted lookup. If it has, it should be compatible with both Python 2 and Python 3.
    """
    if target_splunk_version < "py3_migration":
        return
    reporter_output = ("With the upcoming Splunk Python 3 migration,"
                       " Splunk recommends best practices of upgrading custom search commands"
                       " and scripted lookups to be dual Python 2 and Python 3 compatible."
                       " Using Python 3-only syntax may cause failures on deployments with"
                       " search heads upgraded but indexers on 7.x or below."
                       " If you've finished your upgrade, please disregard this message.")
    custom_commands = app.get_custom_commands()
    if custom_commands.configuration_file_exists():
        file_path = os.path.join("default", "commands.conf")
        for command in custom_commands.get_commands():
            for exe_file in command.executable_files:
                exe_file.ext == '.py'
                reporter.warn(reporter_output, file_path, command.lineno)

    config_file_paths = app.get_config_file_paths("transforms.conf")
    if config_file_paths:
        for directory, filename in config_file_paths.iteritems():
            file_path = os.path.join(directory, filename)
            transforms_conf = app.transforms_conf(directory)
            external_command_stanzas = [section
                                        for section
                                        in transforms_conf.sections()
                                        if section.has_option("external_cmd")]
            application_files = []
            if external_command_stanzas:
                application_files = list(app.iterate_files(types=[".py"]))
            for external_command_stanza in external_command_stanzas:
                # find `external_cmd` in the sections of transforms.conf
                external_command = external_command_stanza.get_option("external_cmd").value
                external_command_lineno = external_command_stanza.get_option("external_cmd").lineno
                external_command_regex_string = r"^[^\s]+\.py(?=\s)"
                external_command_regex = re.compile(external_command_regex_string)
                script_filename_matches = external_command_regex.search(external_command)
                if script_filename_matches:
                    reporter.warn(reporter_output, file_path, external_command_stanza.lineno)


@splunk_appinspect.tags("splunk_appinspect", "py3_migration")
@splunk_appinspect.cert_version(min="1.7.1")
def check_for_reserved_filename_test_py(app, reporter, target_splunk_version):
    """
    Check reserved filename test.py.
    """
    if target_splunk_version < "py3_migration":
        return
    for directory, filename, ext in app.iterate_files(types=['.py']):
        if filename == 'test.py':
            current_file_relative_path = os.path.join(directory, filename)
            reporter.warn("Detect the existence of test.py." 
                            " With the upcoming Splunk Python 3 migration,"
                            " 'test.py' is a reserved file name,"
                            " therefore naming your custom python file(s) 'test.py'"
                            " may cause unpredictable or incorrect output."
                            " Please rename your custom python file(s).", current_file_relative_path)


@splunk_appinspect.tags("splunk_appinspect", "splunk_6_3", "deprecated_feature", "advanced_xml", "py3_migration", 'removed_feature')
@splunk_appinspect.cert_version(min="1.1.11")
def check_for_advanced_xml_module_elements(app, reporter, target_splunk_version):
    """Check for Advanced XML `<module>` elements. The Module system was
    deprecated in Splunk 6.3 as part of the advanced XML deprecation. See:
    http://docs.splunk.com/Documentation/Splunk/latest/Module"""
    # Checks to see if any advanced xml file exists, using the existence of
    # `<module>` elements as a heuristic. This only applies to xml files in
    # default/data/ui/views.
    if target_splunk_version < "splunk_6_3":
        return
    if target_splunk_version < 'py3_migration':
        finding_action, reporter_output = reporter.warn, ("<module> element detected, which implies you're using Advanced XML. "
                        "Advanced XML has been deprecated in Splunk 6.3.")
    else:
        finding_action, reporter_output = reporter.warn, ("With the upcoming Splunk Python 3 migration,"
                                                        " this app is using Advanced XML which will be removed,"
                                                        " and continuing to use it may cause breakage."
                                                        " Please do not use it.")
    check_routine.find_xml_nodes(app,
                   reporter,
                   reporter_output,
                   [check_routine.xml_node('module')],
                   finding_action=finding_action,
                   path='default/data/ui/views')


@splunk_appinspect.tags("splunk_appinspect", "splunk_6_4", "deprecated_feature", "web_conf", "py3_migration", 'removed_feature')
@splunk_appinspect.cert_version(min="1.1.11")
def check_for_splunk_web_legacy_mode(app, reporter, target_splunk_version):
    """Check that the 'appServerPorts' property in the web.conf does not contain
    port 0.
    """
    # Per the documentation
    # This was a temporary setting for use in specific cases where SSO would
    # break using the new mode. These issues have since been resolved, and
    # therefore this workaround is no longer needed. Switching to normal mode is
    # recommended given the performance and configuration benefits

    # appServerPorts is a comma separated list of ports
    if target_splunk_version < 'splunk_6_4':
        return
    try:
        web_config = app.web_conf()
        web_config_file_path = os.path.join("default", "web.conf")

        property_being_checked = "appServerPorts"
        for section in web_config.sections():
            all_sections_with_app_server_ports = [(p, v, lineno)
                                                   for p, v, lineno in section.items()
                                                   if p == property_being_checked]

            for property, value, lineno in all_sections_with_app_server_ports:
                if(property == property_being_checked and
                        "0" in value.split(",")):
                    if target_splunk_version < 'py3_migration': 
                        reporter_output = ("{} use the appServerPorts property with a value of 0 "
                                        "in Stanza {}, which has been deprecated in "
                                        "Splunk 6.4. Please set it to other value, e.g., 8065.").format(web_config_file_path, section.name)
                        reporter.warn(reporter_output, web_config_file_path, lineno)
                    else:
                        reporter_output = ("{} use the appServerPorts property with a value of 0 in Stanza {}."
                                            " With the upcoming Splunk Python 3 migration,"
                                            " this app is using Splunk legacy mode which will be removed,"
                                            " and continuing to use this mode may cause breakage."
                                            " Please set appServerPorts to other value, e.g., 8065.").format(web_config_file_path, section.name)
                        reporter.warn(reporter_output, web_config_file_path, lineno)
    except:
        reporter_output = ("No web.conf file found.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("splunk_appinspect", "splunk_6_6", "deprecated_feature", 'ast', 'py3_migration')
@splunk_appinspect.cert_version(min="1.7.0")
def check_for_app_packages_static_endpoint(app, reporter, target_splunk_version):
    """Check static/app-packages usages
    """
    if target_splunk_version < "splunk_6_6":
        return
    elif target_splunk_version < "py3_migration":
        reporter_output = ("static/app-packages endpoint has been deprecated in Splunk 6.6, "
                        "and might be removed in future version. "
                        "Please do not use this endpoint.")
    else:
        reporter_output = ("With the upcoming Splunk Python 3 migration,"
                        " this app is using static/app-packages endpoint which will be removed,"
                        " and continuing to use it may cause breakage."
                        " Please do not use it.")

    kws = ["static/app-packages"]
    regex_file_types = [".js", ".html", ".xml", ".conf"]

    for matched_file, matched_lineno in check_routine.find_endpoint_usage(
            app=app, kws=kws, regex_file_types=regex_file_types):

        reporter.warn(reporter_output, matched_file, matched_lineno)


@splunk_appinspect.tags("splunk_appinspect", "deprecated_feature", 'py3_migration')
@splunk_appinspect.cert_version(min="1.7.1")
def check_for_python_script_existence(app, reporter, target_splunk_version):
    """Check for existence of Python scripts. All Python scripts must be updated due to the upcoming Splunk Python 3 migration.
    """
    if target_splunk_version < "py3_migration":
        return
    count = 0
    for directory, filename, ext in app.iterate_files(types=['.py', '.py3', '.pyc', '.pyo', '.pyi', '.pyd', '.pyw', '.pyx', '.pxd']):
        count += 1
    report_output = ("Detect existence of Python scirpt."
                     " All Python scripts must be updated due to the upcoming Splunk Python 3 migration."
                     " Please see https://docs.splunk.com/Documentation/Splunk/latest/Python3Migration/AboutMigration for more information."
                     " Any other Python scripts flagged in this scan (if reported in other checks) have special considerations due to the migration, and as a result are being flagged.")
    if count > 0:
        reporter.warn(report_output)