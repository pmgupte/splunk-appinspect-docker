"""
dom.tree unsafe functions
"""
from . import ElementTree