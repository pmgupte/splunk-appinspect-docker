"""
xml unsafe functions
"""
from . import dom
from . import etree
from . import sax