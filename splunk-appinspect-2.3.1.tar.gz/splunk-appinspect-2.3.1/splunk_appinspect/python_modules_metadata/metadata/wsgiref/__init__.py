"""
The Web Server Gateway Interface (WSGI) is a standard interface between web server software and web applications written in Python.
"""
from . import simple_server