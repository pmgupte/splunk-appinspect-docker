"""
xml.dom unsafe functions
"""
from . import minidom
from . import pulldom