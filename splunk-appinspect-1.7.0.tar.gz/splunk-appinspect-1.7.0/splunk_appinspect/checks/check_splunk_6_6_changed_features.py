# Copyright 2018 Splunk Inc. All rights reserved.

"""
### Deprecated or removed features from Splunk Enterprise 6.6

The following features should not be supported in Splunk 6.6 or later. For more, see <a href="http://docs.splunk.com/Documentation/Splunk/6.6.0/ReleaseNotes/Deprecatedfeatures" target="_blank">Deprecated features</a> and <a href="http://docs.splunk.com/Documentation/Splunk/latest/Installation/ChangesforSplunkappdevelopers" target="_blank">Changes for Splunk App developers</a>.
"""

# Python Standard Libraries
import logging

# Custom Libraries
import splunk_appinspect
from splunk_appinspect.python_analyzer.client import Client
from splunk_appinspect.python_analyzer.ast_info_query import Any, Or

logger = logging.getLogger(__name__)


@splunk_appinspect.tags("splunk_appinspect", "splunk_6_6", "deprecated_feature", 'ast')
@splunk_appinspect.cert_version(min="1.7.0")
def check_for_app_packages_static_endpoint(app, reporter):
    """Check app-packages/static usages
    """
    reporter_output = ("static/app-packages endpoint has been deprecated in Splunk 6.6, "
                       "and will be removed in future version. "
                       "Please do not use this endpoint.")
    client = app.python_analyzer_client
    for filepath, ast_info in client.get_all_ast_infos():
        query = ast_info.query().call_nodes()
        query.filter(Any(ast_info.get_literal_string_usage("static/app-packages")))
        query.filter(
                Or(
                    Any(ast_info.get_module_function_call_usage('urllib2', 'urlopen')),
                    Any(ast_info.get_module_function_call_usage('requests', 'get'))
                    )
                )
        usages = query.collect()
        for usage in usages:
            reporter.warn(reporter_output, filepath, usage.lineno)