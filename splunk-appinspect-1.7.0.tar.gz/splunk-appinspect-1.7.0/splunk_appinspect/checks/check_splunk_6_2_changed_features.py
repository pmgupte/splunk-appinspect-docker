# Copyright 2018 Splunk Inc. All rights reserved.

"""
### Deprecated features from Splunk Enterprise 6.2

The following features should not be supported in Splunk 6.2 or later.
https://docs.splunk.com/Documentation/Splunk/6.2.0/ReleaseNotes/Deprecatedfeatures
"""

# Python Standard Libraries
import os
import re
# Third-Party Libraries
import bs4
# Custom Libraries
import splunk_appinspect
from splunk_appinspect.check_routine import *


@splunk_appinspect.tags("splunk_appinspect", "splunk_6_2", "deprecated_feature")
@splunk_appinspect.cert_version(min="1.7.0")
def check_for_simple_xml_row_grouping(app, reporter):
    """Check for the deprecated grouping attribute of `row` node in Simple XML files.
    Use the `<panel>` node instead.
    """
    grouping_re_obj = re.compile(r"""[0-9,"'\s]+""")
    node = xml_node('row')
    node.attrs = {'grouping': grouping_re_obj}
    reporter_output = ("Grouping attribute of <row> was detected, please use "
                        "the <panel> node instead.")
    find_xml_nodes(app, reporter, reporter_output, [node], finding_action=reporter.warn, path='default/data/ui/views')


@splunk_appinspect.tags("splunk_appinspect", "splunk_6_2", "deprecated_feature")
@splunk_appinspect.cert_version(min="1.7.0")
def check_for_populating_search_element_in_dashboard_xml(app, reporter):
    """Check for the deprecated <populatingSearch> and <populatingSavedSearch> elements in dashboard XML files.
    Use the `<search>` element instead.
    """
    nodes = [xml_node('populatingSearch'), xml_node('populatingSavedSearch')]
    reporter_output = ("<{}> element was deprecated in Splunk 6.2 and supposed to be removed in future release, " \
                       "please use the <search> element instead.")
    find_xml_nodes(app, reporter, reporter_output, nodes, finding_action=reporter.warn, path='default/data/ui/views')


@splunk_appinspect.tags("splunk_appinspect", "splunk_6_2", "deprecated_feature")
@splunk_appinspect.cert_version(min="1.7.0")
def check_for_earliest_time_and_latest_time_elements_in_dashboard_xml(app, reporter):
    """Check for the deprecated <earliestTime> and <latestTime> elements in dashboard XML files.
    As of version 6.2 these elements are replaced by <earliest> and <latest> elements.
    """
    nodes = [xml_node('earliestTime'), xml_node('latestTime')]
    reporter_output = ("<{}> element was deprecated in Splunk 6.2. "
                        "please use the <earliest>/<latest> element instead.")
    find_xml_nodes(app, reporter, reporter_output, nodes, finding_action=reporter.warn, path='default/data/ui/views')
