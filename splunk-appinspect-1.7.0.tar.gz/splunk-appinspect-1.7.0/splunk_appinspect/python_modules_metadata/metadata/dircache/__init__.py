'''
manipulate cache files/directories
'''