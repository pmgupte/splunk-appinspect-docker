"""
xml unsafe functions
"""
import dom
import etree
import sax