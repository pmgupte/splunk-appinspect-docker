"""
xml.dom unsafe functions
"""
import minidom
import pulldom