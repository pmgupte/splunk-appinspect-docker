"""
dom.tree unsafe functions
"""
import ElementTree