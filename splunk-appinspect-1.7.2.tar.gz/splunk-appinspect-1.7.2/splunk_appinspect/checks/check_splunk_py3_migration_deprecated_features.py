# Copyright 2019 Splunk Inc. All rights reserved.

"""
### Features impacted by Splunk Python 3 release.

The following features should not be supported in Splunk Enterprise Python 3 release.
"""

# Python Standard Libraries
import logging
import os
import re

# Third-Party Libraries
import bs4

# Custom Libraries
import splunk_appinspect
import splunk_appinspect.check_routine as check_routine

logger = logging.getLogger(__name__)


@splunk_appinspect.tags("splunk_appinspect", "removed_feature", 'ast', 'py3_migration')
@splunk_appinspect.cert_version(min="1.7.1")
def check_for_removed_m2crypto_usage(app, reporter, target_splunk_version):
    """
    Check for the existence of the M2Crypto package usage, which will be removed in the upcoming Splunk Enterprise Python 3 release. 
    """
    # This package was removed in Splunk Python 3 release and App shouldn't use it. However, Since 
    # we don't know whether the user has packaged their own M2Crypto. We only report 
    # warning once the usage is found.
    if target_splunk_version < "py3_migration":
        return
    reporter_output = ("Remove dependencies on the M2Crypto package. "
                       "This package will be removed in the upcoming Splunk Enterprise Python 3 release.")
    client = app.python_analyzer_client
    for file_path, ast_info in client.get_all_ast_infos():
        lines = ast_info.get_module_usage('M2Crypto', lineno_only=True)
        for line in lines:
            reporter.warn(reporter_output, file_path, line)


@splunk_appinspect.tags("splunk_appinspect", "removed_feature", "py3_migration")
def check_for_cherry_py_custom_controller_web_conf_endpoints(app, reporter, target_splunk_version):
    """
	Check for the existence of custom CherryPy endpoints, which must be upgraded to be Python 3-compatible for the upcoming Splunk Enterprise Python 3 release. 
    """
    # Checks to see if [endpoint:*] stanzas are defined in web.conf.
    if target_splunk_version < "py3_migration":
        return
    config_file_paths = app.get_config_file_paths("web.conf")
    if not config_file_paths:
        reporter_output = ("No web.conf file found.")
        reporter.not_applicable(reporter_output)
        return
    for directory, filename in config_file_paths.iteritems():
        file_path = os.path.join(directory, filename)
        reporter_output = ("Update custom CherryPy endpoints to be Python 3-compatible"
						   "for the upcoming Splunk Enterprise Python 3 release."
						   " Splunk Web, which CherryPy endpoints depend on, will support only Python 3.7."
                           " If you've finished your update, please disregard this message.")
        web_conf = app.web_conf(directory)
        for section in web_conf.sections():
            if section.name.startswith("endpoint:"):
                reporter.warn(reporter_output, file_path, section.lineno)


@splunk_appinspect.tags("splunk_appinspect", "py3_migration")
def check_for_existence_of_python_code_block_in_mako_template(app, reporter, target_splunk_version):
    """
	Check for the existence of Python code block in Mako templates, which must be upgraded to be Python 3-compatible for the upcoming Splunk Enterprise Python 3 release. 
    """
    if target_splunk_version < "py3_migration":
        return
    reporter_output = ("Update Mako templates to be Python 3-compatible."
                       " Splunk Web, which Mako templates depend on, will support only Python 3.7."
                       " If you've finished your update, please disregard this message.")
    for dir, file, ext in app.iterate_files(types=['.html']):
        current_file_relative_path = os.path.join(dir, file)
        current_file_full_path = app.get_filename(dir, file)
        if check_routine.is_mako_template(current_file_full_path):
            reporter.warn(reporter_output, current_file_relative_path)


@splunk_appinspect.tags("splunk_appinspect", "py3_migration")
@splunk_appinspect.cert_version(min="1.7.1")
def check_for_reserved_filename_test_py(app, reporter, target_splunk_version):
    """
    Check that there is no file named test.py, which is a reserved filename. 
    """
    if target_splunk_version < "py3_migration":
        return
    for directory, filename, ext in app.iterate_files(types=['.py']):
        if filename == 'test.py':
            current_file_relative_path = os.path.join(directory, filename)
            reporter.warn("Rename the file to avoid namespace conflicts: test.py" 
                          " Use non-reserved filenames that do not conflict with Python standard modules or Splunk libraries.", current_file_relative_path)

@splunk_appinspect.tags("splunk_appinspect", "splunk_6_3", "deprecated_feature", "advanced_xml", "py3_migration", 'removed_feature')
@splunk_appinspect.cert_version(min="1.1.11")
def check_for_advanced_xml_module_elements(app, reporter, target_splunk_version):
    """
	Check that there is no Advanced XML, which was deprecated in Splunk Enterprise 6.3. 
	"""
    # Checks to see if any advanced xml file exists, using the existence of
    # `<module>` elements as a heuristic. This only applies to xml files in
    # default/data/ui/views.
    if target_splunk_version < "splunk_6_3":
        return
    if target_splunk_version < 'py3_migration':
        finding_action, reporter_output = reporter.warn, ("Replace Advanced XML with Simple XML. "
                        "Advanced XML was deprecated in Splunk Enterprise 6.3. ")
    else:
        finding_action, reporter_output = reporter.warn, ("Replace Advanced XML with Simple XML. "
                                                        "Advanced XML was deprecated in Splunk Enterprise 6.3"
                                                        " and will be removed in the upcoming Splunk Enterprise Python 3 release.")
    check_routine.find_xml_nodes(app,
                   reporter,
                   reporter_output,
                   [check_routine.xml_node('module')],
                   finding_action=finding_action,
                   path='default/data/ui/views')


@splunk_appinspect.tags("splunk_appinspect", "splunk_6_4", "deprecated_feature", "web_conf", "py3_migration", 'removed_feature')
@splunk_appinspect.cert_version(min="1.1.11")
def check_for_splunk_web_legacy_mode(app, reporter, target_splunk_version):
    """
	Check that Splunk Web is not in Legacy Mode, which was deprecated in Splunk Enterprise 6.4. 
    """
    # Per the documentation
    # This was a temporary setting for use in specific cases where SSO would
    # break using the new mode. These issues have since been resolved, and
    # therefore this workaround is no longer needed. Switching to normal mode is
    # recommended given the performance and configuration benefits

    # appServerPorts is a comma separated list of ports
    if target_splunk_version < 'splunk_6_4':
        return
    config_file_paths = app.get_config_file_paths("web.conf")
    if not config_file_paths:
        reporter_output = ("No web.conf file found.")
        reporter.not_applicable(reporter_output)
        return
    for directory, filename in config_file_paths.iteritems():
        web_config_file_path = os.path.join(directory, filename)
        web_config = app.web_conf(directory)
        property_being_checked = "appServerPorts"
        for section in web_config.sections():
            all_sections_with_app_server_ports = [(p, v, lineno)
                                                    for p, v, lineno in section.items()
                                                    if p == property_being_checked]

            for property, value, lineno in all_sections_with_app_server_ports:
                if(property == property_being_checked and
                        "0" in value.split(",")):
                    if target_splunk_version < 'py3_migration': 
                        reporter_output = ("Running Splunk Web in Legacy Mode by setting appServerPorts = 0 in web.conf was deprecated in Splunk Enterprise 6.4." 
                                        " Set it to other values, e.g., 8065.")
                        reporter.warn(reporter_output, web_config_file_path, lineno)
                    else:
                        reporter_output = ("Switch from legacy mode to normal mode. "
                                            "Running Splunk Web in Legacy Mode by setting appServerPorts = 0 in web.conf was deprecated. "
                                            "This was a temporary workaround for issues that are now resolved."
                                            "Normal mode provides performance and configuration benefits.").format(web_config_file_path, section.name)
                        reporter.warn(reporter_output, web_config_file_path, lineno)


@splunk_appinspect.tags("splunk_appinspect", "deprecated_feature", "py3_migration")
@splunk_appinspect.cert_version(min="1.7.1")
def check_for_python_script_existence(app, reporter, target_splunk_version):
    """
	Check for the existence of Python scripts, which must be upgraded to be cross-compatible with Python 2 and 3 for the upcoming Splunk Enterprise Python 3 release. 
    """
    if target_splunk_version < "py3_migration":
        return
    count = 0
    for directory, filename, ext in app.iterate_files(types=['.py', '.py3', '.pyc', '.pyo', '.pyi', '.pyd', '.pyw', '.pyx', '.pxd']):
        count += 1
    report_output = ("{} Python files found."
                     " Update these Python scripts to be cross-compatible with Python 2 and 3 for the upcoming Splunk Enterprise Python 3 release."
                     " See https://docs.splunk.com/Documentation/Splunk/latest/Python3Migration/AboutMigration for more information."
                     " If you've finished your update, please disregard this message.")
    if count > 0:
        reporter.warn(report_output.format(count))