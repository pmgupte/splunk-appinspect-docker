"""
Splunk AppInspect documentation metadata generator module
"""
from . import criteria_generator
from .splunk_docs import DocumentationLinks
from . import tag_reference_generator
